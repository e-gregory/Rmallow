# Setup file for testthat tests
# This file is automatically run before all test files

library(RMallow)
